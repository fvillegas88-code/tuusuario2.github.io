# Bitácora de Inteligencia Artificial

## Consulta 1
- **Fecha:** 11/11/2026
- **Herramienta utilizada:** ChatGPT / Gemini
- **Objetivo:** Generar la estructura básica de HTML5 con etiquetas semánticas.
- **Prompt completo:** "Necesito una estructura semántica para un portfolio con encabezado, navegación, presentación, sobre mí, proyectos, habilidades, contacto y pie de página. Usá solamente HTML5, sin CSS, JavaScript ni frameworks."
- **Parte utilizada:** La distribución general de `<header>`, `<main>`, `<section>`, `<article>` y `<footer>`.
- **Cambios realizados por mí:** Reemplacé los textos genéricos por mis proyectos reales e ingresé los IDs correspondientes para la navegación.
- **¿Qué comprendí?** Comprendí cómo conectar los enlaces internos del `<nav>` usando los `id` de cada `<section>`.
- **¿Qué descarté y por qué?** Descarté scripts de JavaScript y enlaces a librerías externas para mantener el proyecto estático y simple.

## Consulta 2
- **Fecha:** 11/11/2026
- **Herramienta utilizada:** ChatGPT / Gemini
- **Objetivo:** Crear variables CSS para definir la paleta de colores y el diseño de tarjetas.
- **Prompt completo:** "Mi portfolio tiene estilo limpio y profesional, usa tonos azules y grises, y debe transmitir orden. Creá un CSS inicial con variables de color, tipografía legible, espaciados y tarjetas."
- **Parte utilizada:** El bloque `:root` y la clase `.tarjeta`.
- **Cambios realizados por mí:** Ajusté los códigos de color en hexadecimal para que coincidan con mi paleta de planificación.
- **¿Qué comprendí?** Aprendí a declarar y reutilizar variables CSS con la sintaxis `var(--nombre)`.
- **¿Qué descarté y por me?** Descarté una grilla compleja con Flexbox avanzado porque todavía no la necesitaba para la versión 0.1.

## Consulta 3 (Versión Final)
- **Fecha:** 11/11/2026
- **Herramienta utilizada:** ChatGPT / Gemini
- **Objetivo:** Aplicar mejoras de navegación responsive, maquetación horizontal mediante CSS Grid y rediseño de la sección de habilidades.
- **Prompt completo:** "Necesito organizar las tarjetas de proyectos horizontalmente usando CSS Grid, agregar líneas decorativas a los títulos centrados de proyectos, habilidades y contacto, y convertir la lista de habilidades en tarjetas dinámicas tipo cápsula."
- **Parte utilizada:** `grid-template-columns: repeat(auto-fit, minmax(280px, 1fr))` para proyectos y la clase `.lista-habilidades` con diseño tipo *pills*.
- **Cambios realizados por mí:** Adapté los proyectos al rubro automotor (taller mecánico, car detail y auto propio) y configuré la navegación menú hamburguesa.
- **¿Qué comprendí?** Aprendí a estructurar maquetaciones adaptativas con CSS Grid y a usar pseudo-elementos (`::after`) para detalles visuales.
- **¿Qué descarté y por qué?** Descarté librerías externas de íconos o frameworks como Bootstrap para mantener el código ligero y nativo.
